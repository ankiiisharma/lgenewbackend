-- AlterTable
ALTER TABLE "comments" ALTER COLUMN "name" DROP NOT NULL;
